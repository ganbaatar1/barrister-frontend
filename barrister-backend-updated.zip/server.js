const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const initializeFirebaseAdmin = require("./config/firebaseAdmin");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5050;

app.use(cors());
app.use(express.json());

initializeFirebaseAdmin();

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`✅ Сервер амжилттай ажиллаж байна — порт: ${PORT}`);
  });
});

app.get("/", (req, res) => {
  res.send("✅ Backend сервер амжилттай ажиллаж байна!");
});
