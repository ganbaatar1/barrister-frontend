const admin = require("firebase-admin");

module.exports = function initializeFirebaseAdmin() {
  const serviceAccountBase64 = process.env.FIREBASE_SERVICE_ACCOUNT_BASE64;
  if (!serviceAccountBase64) {
    console.error("❌ FIREBASE_SERVICE_ACCOUNT_BASE64 environment variable байхгүй байна!");
    return;
  }

  try {
    const serviceAccountJSON = JSON.parse(Buffer.from(serviceAccountBase64, "base64").toString("utf-8"));

    admin.initializeApp({
      credential: admin.credential.cert(serviceAccountJSON),
    });

    console.log("✅ Firebase Admin амжилттай эхэллээ.");
  } catch (error) {
    console.error("❌ Firebase Admin эхлүүлэхэд алдаа гарлаа:", error.message);
  }
};
